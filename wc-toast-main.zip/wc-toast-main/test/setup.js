import 'regenerator-runtime/runtime';
import '../src/index.js';
